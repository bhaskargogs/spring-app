package com;

public class HelloMobile {
	public static void main(String[] args) {
			Mobile mobile=new Mobile();
			System.out.println(mobile);
			int result=mobile.fact(7);
			System.out.println("Fact of = 7 is "+result );
	}
}
